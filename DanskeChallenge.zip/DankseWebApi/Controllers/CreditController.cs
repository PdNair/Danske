﻿using DankseWebApi.Models;
using DankseWebApi.Services;
using Microsoft.AspNetCore.Mvc;
using System;

namespace DankseWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CreditController : ControllerBase
    {
        // commenting out for easier unit testing
        //private readonly ICreditService creditService;
        ICreditService creditService = new CreditService();
        public CreditController(/* ICreditService creditService */)
        {
            this.creditService = creditService ?? throw new ArgumentNullException(nameof(creditService));
        }

        [HttpPost]
        [Route("calc-credit")]
        public IActionResult GetCredit(CreditApplyModel model)
        {
            var result = creditService.CalculateCredit(model);
            return Ok(result);
        }
    }
}
