﻿using DankseWebApi.Models;
using DankseWebApi.Services;
using Microsoft.AspNetCore.Mvc;
using System;

namespace DankseWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CreditController : ControllerBase
    {
        private readonly ICreditService creditService;
        public CreditController(ICreditService creditService)
        {
            this.creditService = creditService ?? throw new ArgumentNullException(nameof(creditService));
        }

        [HttpPost]
        [Route("calc-credit")]
        public IActionResult GetCredit(CreditApplyModel model)
        {
            var result = creditService.CalculateCredit(model);
            return Ok(result);
        }
    }
}
