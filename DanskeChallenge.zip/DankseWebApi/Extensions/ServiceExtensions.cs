﻿using DankseWebApi.Services;
using Microsoft.Extensions.DependencyInjection;

namespace DankseWebApi
{
    public static class ServiceExtensions
    {
        // adding all user defined services
        public static IServiceCollection AddControllerServices(this IServiceCollection services)
        {   
            services.AddScoped<ICreditService, CreditService>();
            return services;
        }
    }
}
