﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using System;

namespace DankseWebApi
{
    public static class SwaggerServiceExtensions
    {
        // Code for Swagger description
        public static IServiceCollection AddSwaggerDocumentation(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "Danske WebApi",
                    Description = "The Web service will read data from log files and provides data to clients",
                    TermsOfService = new Uri("https://danskebank.com/"),
                    Contact = new OpenApiContact
                    {
                        Name = "PD Nair",
                        Email = "priyadarsan06@gmail.com",
                        Url = new Uri("https://www.linkedin.com/in/priyadarsan-muralidharan-nair-b2643693/"),
                    },
                    License = new OpenApiLicense
                    {
                        Name = "Danske Bank",
                        Url = new Uri("https://en.wikipedia.org/wiki/Danske_Bank"),
                    }
                });
            });
            return services;
        }
    }
}
