﻿using System.ComponentModel.DataAnnotations;

namespace DankseWebApi.Models
{
    public class CreditApplyModel
    {
        [Required]
        [Range(1, double.MaxValue, ErrorMessage = "Only positive number allowed")]
        public double Amount { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Only positive number allowed")]
        public int Term { get; set; }

        [Required]
        [Range(0, double.MaxValue, ErrorMessage = "Only positive number allowed")]
        public double ExistingAmount { get; set; }
    }
}