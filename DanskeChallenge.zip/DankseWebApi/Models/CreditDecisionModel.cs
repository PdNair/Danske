﻿namespace DankseWebApi.Models
{
    public class CreditDecisionModel
    {
        public bool Decision { get; set; } = false;
        public int Interest { get; set; }
    }
}