﻿using DankseWebApi.Models;

namespace DankseWebApi.Services
{
    /// <summary>
    /// ICreditService
    /// </summary>

    public interface ICreditService
    {
        /// <summary>
        /// Calculate the Credit Amount
        /// </summary>
        public CreditDecisionModel CalculateCredit(CreditApplyModel model);
    }
    public class CreditService : ICreditService
    {
        public CreditService() { }

        //If the futureDebt is between 39000-40000 or 59000-60000, the interest condition is not stated.
        //So I am taking the 4% interest up to 40000 and 5% interest up to 60000
        public CreditDecisionModel CalculateCredit(CreditApplyModel model)
        {
            CreditDecisionModel credit = new CreditDecisionModel();
            if (model.Amount < 2000)
                credit.Decision = false;
            else if (model.Amount>=2000 && model.Amount<=69000)
                credit.Decision = true;
            else
                credit.Decision = false;
            
            if (credit.Decision)
            {
                double futureDebt = model.Amount + model.ExistingAmount;
                if (futureDebt <= 20000)
                    credit.Interest = 3;
                else if (futureDebt>20000 && futureDebt <= 40000)
                    credit.Interest = 4;
                else if (futureDebt>40000 && futureDebt <= 60000)
                    credit.Interest = 5;
                else
                    credit.Interest = 6;
            }
            return credit;
        }
    }
}
