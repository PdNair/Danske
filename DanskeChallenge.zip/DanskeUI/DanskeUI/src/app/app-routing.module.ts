import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreditComponent } from '../credit/credit.component';

const routes: Routes = [
  { path: '', redirectTo: 'credit', pathMatch: 'full' },
  { path: 'credit', component: CreditComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
