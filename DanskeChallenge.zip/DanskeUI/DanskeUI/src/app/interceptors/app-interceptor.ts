import { HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpParams, HttpRequest } from "@angular/common/http";
import { Injectable, Injector } from "@angular/core";
import { mergeMap, Observable, of } from "rxjs";
import { EnvSettingsService } from "src/environments/env-settings.service";

@Injectable()

export class AppInterceptor implements HttpInterceptor {
    private envSettings: EnvSettingsService;

    constructor(
        private injector: Injector
    ) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        let jwtToken = sessionStorage.getItem('jwtToken');
        if (jwtToken) {
            const authReq = request.clone({
                headers: new HttpHeaders({
                  'Content-Type':  'application/json',
                  'Authorization': `Bearer ${jwtToken}`
                })
            });
            return next.handle(authReq);
        }
        return next.handle(request);
    }
}