import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CreditDecisionModel } from "./model/credit-decision";
import { CreditService } from './services/credit.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CreditApply } from './model/credit-apply';

@Component({
  selector: 'credit',
  templateUrl: './credit.component.html',
  styleUrls: ['./credit.component.css']
})
export class CreditComponent implements OnInit {
  title = 'DanskeUI- Staging';
  creditDecision: CreditDecisionModel;
  nums: Array<number> = [5, 10];
  searchText: string ='';
  form: FormGroup;
  isLoading: boolean = true;
  processed: boolean = false;
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private creditService: CreditService 
  ) { }

  ngOnInit(): void {
    this.form = this.fb.group({
      amount: new FormControl('', Validators.required),
      term: new FormControl('', Validators.required),
      existing: new FormControl('', Validators.required)
    });
  }

  onCalculate() {
    let model = this.assignModel();
    this.creditService.calculateCredit(model).subscribe(data => {
      this.creditDecision = data;
      this.processed = true;
    });
  }

  onReset() {
    this.form.reset();
    this.processed = false;
  }

  private assignModel() : CreditApply{
    let model = new CreditApply();
    model.amount = Number(this.form.get('amount')?.value);
    model.term = Number(this.form.get('term')?.value);
    model.existingAmount = Number(this.form.get('existing')?.value);
    return model;
  }
}
