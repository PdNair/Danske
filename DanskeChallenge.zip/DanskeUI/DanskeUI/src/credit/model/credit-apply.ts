export class CreditApply {
    amount : number;
    term : number;
    existingAmount: number;
}