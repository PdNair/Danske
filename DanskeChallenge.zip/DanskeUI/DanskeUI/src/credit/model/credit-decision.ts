export class CreditDecisionModel {
    decision: boolean;
    interest: number;
}