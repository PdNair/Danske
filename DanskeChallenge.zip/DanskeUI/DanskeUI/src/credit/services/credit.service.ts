import { Injectable } from "@angular/core";
import { EnvSettingsService } from '../../environments/env-settings.service';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from "rxjs";
import { CreditDecisionModel } from "../model/credit-decision";
import { CreditApply } from "../model/credit-apply";

@Injectable({
    providedIn: 'root'
})

export class CreditService {
    private defaultUrl = this.envSettings.webApiHost;
    private apiUrl = `${this.defaultUrl}/api/Credit/`;
    constructor(
        private http: HttpClient,
        private envSettings: EnvSettingsService,
    ) { }

    calculateCredit(model: CreditApply) : Observable<CreditDecisionModel>{
        return this.http.post<CreditDecisionModel>(this.apiUrl+'calc-credit', model).pipe(
            map((result : CreditDecisionModel) => {
                return result;
            })
        );
    }

}