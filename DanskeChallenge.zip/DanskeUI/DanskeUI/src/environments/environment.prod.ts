export const environment = {
  production: true,
  hostname: 'http://localhost:4200/',
  webApiHost: 'https://localhost:44312',
  enableClientRedirection: false,
  enableRequestEncryption : false
};
