using DankseWebApi.Controllers;
using DankseWebApi.Models;
using DankseWebApi.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using Xunit;

namespace DanskeUnitTest
{
    public class CreditTest
    {
        private readonly ICreditService creditService;
        private readonly CreditController controller;
        public CreditTest()
        {
            creditService = new CreditService();
            controller = new CreditController(creditService);
        }
        [Fact]
        public void LoanAmount_Lessthan2000()
        {
            CreditApplyModel mockData = GenerateMockDataModel(1000, 0, 10);
            Assert.False(StartTest(mockData).Decision);
        }

        [Fact]
        public void LoanAmount_Greaterthan2000_Lessthan69000()
        {
            var mockData = GenerateMockDataModel(3000, 0, 10);
            Assert.True(StartTest(mockData).Decision);
        }

        [Fact]
        public void LoanAmount_Greaterthan69000()
        {
            var mockData = GenerateMockDataModel(75000, 0, 10);
            Assert.False(StartTest(mockData).Decision);
        }

        [Fact]
        public void FutureDebt_Lessthan20000()
        {
            var mockData = GenerateMockDataModel(10000, 5000, 10);
            var result = StartTest(mockData);
            Assert.True(result.Decision);
            Assert.Equal(3, result.Interest);
        }

        [Fact]
        public void FutureDebt_Greaterthan20000_LessThan40000()
        {
            var mockData = GenerateMockDataModel(15000, 15000, 10);
            var result = StartTest(mockData);
            Assert.True(result.Decision);
            Assert.Equal(4, result.Interest);
        }

        [Fact]
        public void FutureDebt_Greaterthan40000_LessThan60000()
        {
            var mockData = GenerateMockDataModel(25000, 25000, 10);
            var result = StartTest(mockData);
            Assert.True(result.Decision);
            Assert.Equal(5, result.Interest);
        }

        [Fact]
        public void FutureDebt_Greaterthan60000()
        {
            var mockData = GenerateMockDataModel(35000, 35000, 10);
            var result = StartTest(mockData);
            Assert.True(result.Decision);
            Assert.Equal(6, result.Interest);
        }
        private CreditApplyModel GenerateMockDataModel(double amount, double existing, int term)
        {
            CreditApplyModel model = new CreditApplyModel
            {
                Amount = amount,
                ExistingAmount = existing,
                Term = term
            };
            return model;
        }

        private CreditDecisionModel StartTest(CreditApplyModel mockData)
        {   
            IActionResult actionResult = controller.GetCredit(mockData);
            OkObjectResult okResult = (OkObjectResult)actionResult;
            CreditDecisionModel result = (CreditDecisionModel)okResult.Value;
            return result;
        }
    }
}
